/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.practical5files;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author М_З_А
 */
public class Practical5Files {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.println("Практика №5, Новиков Матвей, РИБО-01-21, Вариант №4");
        System.out.println("Укажите путь к директории (пример: С:\\Users\\Admin\\Some_Directory): ");
        String pt = scan.next();
    ArrayList<File> fileList = new ArrayList<>();
    searchFiles(new File(pt), fileList);
    Collections.sort(fileList);
    for(File file : fileList){
        System.out.println(file.getAbsolutePath() + " " + file.length());
    }
    }
    
    public static void searchFiles(File rootFile, List<File> fileList){
        Scanner scan = new Scanner(System.in);
        System.out.println("Введите расширение файлов, которые необходимо найти (пример: txt или docx и т.п. (Без точки)),"
                + " при открытии новой директории можно будет выбрать другое расширение файла или оставить первоначальное:");
        String rs = scan.next();
        FileParam f1 = new FileParam(rs);
            if (rootFile.isDirectory()){
                File[] directoryFiles = rootFile.listFiles();
                    if (directoryFiles != null){
                        for(File file : directoryFiles){
                            if(file.isDirectory()){
                                searchFiles(file, fileList);
                            } else {
                                if(file.getName().toLowerCase().endsWith(f1.getStr())){
                                    fileList.add(file);
                                }
                            }
            }
            }
            }
        }
}
